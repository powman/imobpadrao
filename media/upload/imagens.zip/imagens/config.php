<?php
$server = "localhost";
$username = "netcom_imob";
$password = "netn3t";
$dbname = "netcom_imob_padrao";
?>